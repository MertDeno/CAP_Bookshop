jQuery.sap.declare("ListReportApp.Component");
sap.ui.getCore().loadLibrary("sap.ui.generic.app");
jQuery.sap.require("sap.ui.generic.app.AppComponent");

sap.ui.generic.app.AppComponent.extend("ListReportApp.Component", {
	metadata: {
		"manifest": "json"
	}
});